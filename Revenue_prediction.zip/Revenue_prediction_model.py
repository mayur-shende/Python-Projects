#!/usr/bin/env python
# coding: utf-8

# **Import the libraries**
# 

# In[ ]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# **Load the dataset**

# In[ ]:


df=pd.read_csv("revenue_prediction.csv")


# In[ ]:


df.head()


# **Examining missing values in a dataset**

# In[ ]:


df.isnull().sum()


# **Drop irrelevant columns**

# In[ ]:


df=df.drop(columns=["Id","Name","Franchise","Category","City","No_Of_Item"])


# In[ ]:


df.head()


# In[ ]:


df.shape


# **Create independent feature and dependent variable**

# In[ ]:


x=df.iloc[:,:-1].values
y=df.iloc[:,-1].values  


# **Split the dataset into Training set and Test set**

# In[ ]:


from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=42)


# In[ ]:


print(x_train)


# In[ ]:


print(x_test)


# In[ ]:


print(y_train)


# In[ ]:


print(y_test)


# **Training the Simple Linear Regression model on the Training set**

# In[ ]:


from sklearn.linear_model import LinearRegression
regressor=LinearRegression()
regressor.fit(x_train,y_train)


# **Predicting the Test set results**

# In[ ]:


y_pred=regressor.predict(x_test)


# In[ ]:


y_pred


# **Visualising the Training set results**

# In[ ]:


plt.scatter(x_train,y_train,color="blue")
plt.plot(x_train,regressor.predict(x_train),color="green")
plt.title("Revenue vs orders")
plt.xlabel("orders")
plt.ylabel("Revenue")



# **Visualising the Test set results**

# In[ ]:


plt.scatter(x_test,y_test,color="blue")
plt.plot(x_train,regressor.predict(x_train),color="green")
plt.title("Revenue vs orders")
plt.xlabel("orders")
plt.ylabel("Revenue")


# **Accuracy of the Model**

# In[ ]:


from sklearn.metrics import r2_score


# In[ ]:


score=r2_score(y_pred,y_test)


# In[ ]:


score

